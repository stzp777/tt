# Multi-Agent LLM System

A multi-agent LLM system designed to perform as an AI assistant, based on the architecture and design of [LangManus](https://github.com/langmanus/langmanus/).

## Architecture

This system implements a hierarchical multi-agent architecture where specialized agents work together to accomplish complex tasks:

- **Coordinator** - Entry point that handles initial interactions and routes tasks
- **Planner** - Analyzes tasks and creates execution strategies
- **Supervisor** - Oversees and manages the execution of other agents
- **Researcher** - Gathers and analyzes information using search and web crawling
- **Coder** - Handles code generation and modifications
- **Browser** - Performs web browsing and information retrieval
- **Reporter** - Generates reports and summaries of the workflow results

## Features

- **Multi-tier LLM architecture**: Uses different models for reasoning vs. basic tasks
- **Specialized tools**:
  - **Search Tool**: Quick information retrieval from the web
  - **Crawl Tool**: Deep web crawling and content extraction using [crawl4ai](https://github.com/unclecode/crawl4ai)
  - **Python REPL**: Code execution for data analysis
  - **Browser Tool**: Web page interaction

## Setup

### Prerequisites

- Python 3.10+
- pip or another Python package manager

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/multi-agent-llm.git
cd multi-agent-llm
```

2. Install dependencies
```bash
pip install -e .
```

3. Configure environment variables
```bash
cp .env.example .env
# Edit .env with your API keys
```

## Usage

### Running the Agent Workflow

```python
from src.workflow import run_agent_workflow

# Run the agent workflow with a user query
result = run_agent_workflow("Find information about LLM agent architectures")
print(result)
```

### Using the Web Crawl Tool Directly

```python
from src.tools import crawl_tool

# Crawl a website with specific parameters
result = crawl_tool(
    url="https://example.com",
    depth=2,               # Follow links up to 2 levels deep
    max_pages=10,          # Crawl up to 10 pages
    css_selectors=["h1", "p.main-content"]  # Extract content from these selectors
)

# Print the results
print(result)
```

### Example Scripts

Check the `examples/` directory for sample scripts demonstrating tool usage:

```bash
# Example of using the crawl tool
python examples/crawl_example.py https://example.com 1 3
```

## License

MIT 