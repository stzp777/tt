#!/usr/bin/env python
"""
Multi-Agent LLM System
Main entry point for running the agent workflow
"""

import argparse
import logging
from src.workflow import run_agent_workflow

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

def main():
    """Main function to run the agent workflow from command line"""
    parser = argparse.ArgumentParser(description="Run the multi-agent LLM system")
    parser.add_argument(
        "input", nargs="?", type=str, help="The user query or request"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug level logging"
    )
    parser.add_argument(
        "--interactive", "-i", action="store_true", help="Run in interactive mode"
    )
    args = parser.parse_args()
    
    if args.interactive:
        print("Running in interactive mode. Type 'exit' to quit.")
        while True:
            user_input = input("\nYour request: ")
            if user_input.lower() == "exit":
                break
            try:
                result = run_agent_workflow(user_input, args.debug)
                print("\nResult:", result["messages"][-1].content)
            except Exception as e:
                print(f"Error: {e}")
    elif args.input:
        result = run_agent_workflow(args.input, args.debug)
        print(result["messages"][-1].content)
    else:
        parser.print_help()

if __name__ == "__main__":
    main() 