"""
Agent implementations for the multi-agent LLM system
"""

from langgraph.prebuilt import create_react_agent

from src.prompts import apply_prompt_template
from src.tools import (
    search_tool,
    python_repl_tool,
    browser_tool,
    crawl_tool,
)

from src.llms.llm import get_llm_by_type
from src.config.agents import AGENT_LLM_MAP


def create_agent(agent_type: str, tools: list, prompt_template: str):
    """Factory function to create agents with consistent configuration.
    
    Args:
        agent_type: Type of agent (researcher, coder, etc.)
        tools: List of tools the agent can use
        prompt_template: Name of the prompt template to use
        
    Returns:
        A configured agent ready for invocation
    """
    return create_react_agent(
        get_llm_by_type(AGENT_LLM_MAP[agent_type]),
        tools=tools,
        prompt=lambda state: apply_prompt_template(prompt_template, state),
    )


# Create specialized agents using the factory function
research_agent = create_agent("researcher", [search_tool, crawl_tool], "researcher")
coder_agent = create_agent("coder", [python_repl_tool], "coder")
browser_agent = create_agent("browser", [browser_tool], "browser")
reporter_agent = create_agent("reporter", [], "reporter") 