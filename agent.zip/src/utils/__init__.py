"""
Utility functions for the multi-agent LLM system
""" 