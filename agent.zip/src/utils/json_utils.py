"""
JSON utility functions
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

def extract_json_from_markdown(text: str) -> str:
    """Extract JSON from a markdown code block.
    
    Args:
        text: The text containing a markdown code block with JSON
        
    Returns:
        The extracted JSON string
    """
    # Look for JSON code blocks
    json_pattern = r"```(?:json)?\s*([\s\S]*?)\s*```"
    matches = re.findall(json_pattern, text)
    
    if matches:
        return matches[0].strip()
    
    return text

def repair_json_output(text: str) -> str:
    """Try to repair potentially malformed JSON in text.
    
    Args:
        text: Text that may contain JSON
        
    Returns:
        Fixed JSON string if possible, or the original text
    """
    try:
        # First try to see if it's valid JSON already
        json.loads(text)
        return text
    except json.JSONDecodeError:
        # If not, try to extract from markdown
        extracted = extract_json_from_markdown(text)
        try:
            # See if the extracted text is valid JSON
            json.loads(extracted)
            return extracted
        except json.JSONDecodeError:
            logger.warning("Failed to repair JSON. Returning original text.")
            return text 