"""
Agent configuration settings
"""

import os

# Map agent types to LLM types (reasoning, basic)
AGENT_LLM_MAP = {
    "coordinator": "reasoning",   # Entry point, needs strong reasoning
    "planner": "reasoning",       # Planning needs strong reasoning
    "supervisor": "reasoning",    # Decision making needs strong reasoning
    "researcher": "basic",        # Research can use basic model
    "coder": "basic",             # Coding can use basic model
    "browser": "basic",           # Browsing can use basic model
    "reporter": "basic",          # Reporting can use basic model
}

# Default model names
DEFAULT_REASONING_MODEL = os.getenv("REASONING_MODEL", "gpt-4o")
DEFAULT_BASIC_MODEL = os.getenv("BASIC_MODEL", "gpt-3.5-turbo") 