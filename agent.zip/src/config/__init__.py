"""
Configuration settings for the multi-agent LLM system
"""

import os
import dotenv

# Load environment variables from .env file
dotenv.load_dotenv()

# Team member definitions
TEAM_MEMBERS = [
    "coordinator",
    "planner",
    "supervisor",
    "researcher", 
    "coder",
    "browser",
    "reporter",
] 