"""
Graph builder for the multi-agent workflow
"""

from langgraph.graph import StateGraph, START

from .types import State
from .nodes import (
    coordinator_node,
    planner_node,
    supervisor_node,
    research_node,
    code_node,
    browser_node,
    reporter_node,
)


def build_graph():
    """Build and return the agent workflow graph."""
    builder = StateGraph(State)
    
    # Add the nodes to the graph
    builder.add_node("coordinator", coordinator_node)
    builder.add_node("planner", planner_node)
    builder.add_node("supervisor", supervisor_node)
    builder.add_node("researcher", research_node)
    builder.add_node("coder", code_node)
    builder.add_node("browser", browser_node)
    builder.add_node("reporter", reporter_node)
    
    # Start with the coordinator
    builder.add_edge(START, "coordinator")
    
    # Set up edges between nodes
    # The supervisor will route to the appropriate next node
    builder.add_conditional_edges(
        "supervisor",
        lambda state: state.get("next", "FINISH"),
        {
            "coordinator": "coordinator",
            "planner": "planner",
            "researcher": "researcher",
            "coder": "coder",
            "browser": "browser",
            "reporter": "reporter",
            "FINISH": "__end__",
        }
    )
    
    return builder.compile() 