"""
Type definitions for the multi-agent graph
"""

from typing import TypedDict, List, Dict, Any, Optional, Literal
from typing_extensions import NotRequired

# Define the structure of state passed between nodes
class State(TypedDict):
    """State dictionary passed between graph nodes."""
    messages: List[Dict[str, Any]]
    TEAM_MEMBERS: List[str]
    full_plan: NotRequired[str]
    next: NotRequired[str]
    deep_thinking_mode: NotRequired[bool]

# Define the router schema for supervisor decisions
class Router(TypedDict):
    """Schema for supervisor routing decisions."""
    next: str 