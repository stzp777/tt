"""
Graph module for the multi-agent workflow
"""

from .builder import build_graph 