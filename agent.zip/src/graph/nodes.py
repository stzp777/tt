"""
Node implementations for the agent workflow graph
"""

import logging
import json
from typing import Literal
from copy import deepcopy

from langchain_core.messages import HumanMessage
from langgraph.types import Command

from src.agents import research_agent, coder_agent, browser_agent, reporter_agent
from src.llms.llm import get_llm_by_type
from src.config import TEAM_MEMBERS
from src.config.agents import AGENT_LLM_MAP
from src.prompts.template import apply_prompt_template
from .types import State, Router

logger = logging.getLogger(__name__)

RESPONSE_FORMAT = "Response from {}:\n\n<response>\n{}\n</response>\n\n*Please execute the next step.*"


def research_node(state: State) -> Command[Literal["supervisor"]]:
    """Node for the researcher agent that performs research tasks."""
    logger.info("Research agent starting task")
    result = research_agent.invoke(state)
    logger.info("Research agent completed task")
    response_content = result["messages"][-1].content
    logger.debug(f"Research agent response: {response_content}")
    return Command(
        update={
            "messages": [
                HumanMessage(
                    content=response_content,
                    name="researcher",
                )
            ]
        },
        goto="supervisor",
    )


def code_node(state: State) -> Command[Literal["supervisor"]]:
    """Node for the coder agent that executes Python code."""
    logger.info("Code agent starting task")
    result = coder_agent.invoke(state)
    logger.info("Code agent completed task")
    response_content = result["messages"][-1].content
    logger.debug(f"Code agent response: {response_content}")
    return Command(
        update={
            "messages": [
                HumanMessage(
                    content=response_content,
                    name="coder",
                )
            ]
        },
        goto="supervisor",
    )


def browser_node(state: State) -> Command[Literal["supervisor"]]:
    """Node for the browser agent that performs web browsing tasks."""
    logger.info("Browser agent starting task")
    result = browser_agent.invoke(state)
    logger.info("Browser agent completed task")
    response_content = result["messages"][-1].content
    logger.debug(f"Browser agent response: {response_content}")
    return Command(
        update={
            "messages": [
                HumanMessage(
                    content=response_content,
                    name="browser",
                )
            ]
        },
        goto="supervisor",
    )


def reporter_node(state: State) -> Command[Literal["supervisor"]]:
    """Node for the reporter agent that creates final reports."""
    logger.info("Reporter agent starting task")
    result = reporter_agent.invoke(state)
    logger.info("Reporter agent completed task")
    response_content = result["messages"][-1].content
    logger.debug(f"Reporter agent response: {response_content}")
    return Command(
        update={
            "messages": [
                HumanMessage(
                    content=response_content,
                    name="reporter",
                )
            ]
        },
        goto="supervisor",
    )


def supervisor_node(state: State) -> Command[Literal[*TEAM_MEMBERS, "__end__"]]:
    """Supervisor node that decides which agent should act next."""
    logger.info("Supervisor evaluating next action")
    messages = apply_prompt_template("supervisor", state)
    # Preprocess messages to make supervisor execute better
    messages = deepcopy(messages)
    for message in messages:
        if hasattr(message, "name") and message.name in TEAM_MEMBERS:
            message.content = RESPONSE_FORMAT.format(message.name, message.content)
    
    response = (
        get_llm_by_type(AGENT_LLM_MAP["supervisor"])
        .with_structured_output(schema=Router, method="json_mode")
        .invoke(messages)
    )
    goto = response["next"]
    logger.debug(f"Supervisor response: {response}")

    if goto == "FINISH":
        goto = "__end__"
        logger.info("Workflow completed")
    else:
        logger.info(f"Supervisor delegating to: {goto}")

    return Command(goto=goto, update={"next": goto})


def planner_node(state: State) -> Command[Literal["supervisor"]]:
    """Planner node that generates the full plan."""
    logger.info("Planner generating full plan")
    messages = apply_prompt_template("planner", state)
    
    # Use reasoning LLM if deep thinking mode is enabled
    llm = get_llm_by_type("basic")
    if state.get("deep_thinking_mode"):
        llm = get_llm_by_type("reasoning")
    
    response = llm.invoke(messages)
    response_content = response.content
    logger.debug(f"Planner response: {response_content}")

    try:
        # Try to extract JSON from the response if it's in a code block
        if "```json" in response_content and "```" in response_content:
            start = response_content.find("```json") + 7
            end = response_content.rfind("```")
            json_str = response_content[start:end].strip()
            json_obj = json.loads(json_str)
            # Convert back to pretty-printed JSON string
            full_plan = json.dumps(json_obj, indent=2)
        else:
            # If not in a code block, try to parse the whole response
            json_obj = json.loads(response_content)
            full_plan = json.dumps(json_obj, indent=2)
            
    except json.JSONDecodeError:
        logger.warning("Failed to parse JSON from planner response")
        full_plan = response_content

    return Command(
        update={
            "messages": [HumanMessage(content=response_content, name="planner")],
            "full_plan": full_plan,
        },
        goto="supervisor",
    )


def coordinator_node(state: State) -> Command[Literal["planner", "__end__"]]:
    """Coordinator node that communicates with the user."""
    logger.info("Coordinator evaluating request")
    messages = apply_prompt_template("coordinator", state)
    response = get_llm_by_type(AGENT_LLM_MAP["coordinator"]).invoke(messages)
    response_content = response.content
    logger.debug(f"Coordinator response: {response_content}")

    goto = "__end__"
    if "handoff_to_planner" in response_content:
        goto = "planner"
        logger.info("Coordinator handing off to planner")
    else:
        logger.info("Coordinator responding directly")

    # Update the messages in state with the coordinator's response
    return Command(
        update={"messages": state["messages"] + [{"role": "assistant", "content": response_content}]},
        goto=goto,
    ) 