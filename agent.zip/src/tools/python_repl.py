"""
Python REPL tool implementation
"""

import sys
import logging
from io import StringIO
from contextlib import redirect_stdout, redirect_stderr
from typing import Dict, Any

from langchain_core.tools import tool

logger = logging.getLogger(__name__)

@tool
def python_repl_tool(code: str) -> str:
    """Execute Python code and return the result.
    
    Args:
        code: The Python code to execute
        
    Returns:
        The output of the executed code
    """
    logger.info("Executing Python code")
    logger.debug(f"Code to execute: {code}")
    
    # Capture stdout and stderr
    stdout_capture = StringIO()
    stderr_capture = StringIO()
    
    try:
        # Redirect stdout and stderr to our capture objects
        with redirect_stdout(stdout_capture), redirect_stderr(stderr_capture):
            # Execute the code
            exec_globals = {}
            exec(code, exec_globals)
            
        # Get the captured output
        stdout_output = stdout_capture.getvalue()
        stderr_output = stderr_capture.getvalue()
        
        # Combine the outputs
        if stderr_output:
            result = f"Error:\n{stderr_output}\n\nOutput:\n{stdout_output}"
        else:
            result = stdout_output if stdout_output else "Code executed successfully with no output."
            
    except Exception as e:
        result = f"Error executing code: {str(e)}"
        logger.error(f"Error executing Python code: {str(e)}")
    
    logger.debug(f"Python execution result: {result}")
    return result 