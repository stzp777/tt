"""
Web crawling tool implementation using crawl4ai
"""

import logging
import asyncio
from typing import Dict, Any, List, Optional, Union
import json

from langchain_core.tools import tool
from crawl4ai import AsyncWebCrawler

logger = logging.getLogger(__name__)

@tool("web_crawler")
def crawl_tool(url: str, 
               depth: int = 1, 
               max_pages: int = 5, 
               wait_time: float = 0.5,
               css_selectors: Optional[List[str]] = None,
               follow_links: bool = True) -> Union[str, List[Dict[str, Any]]]:
    """Crawl a website and extract content.
    
    Args:
        url: The starting URL to crawl
        depth: How many levels of links to follow (default: 1)
        max_pages: Maximum number of pages to crawl (default: 5)
        wait_time: Time to wait between requests in seconds (default: 0.5)
        css_selectors: List of CSS selectors to extract specific content (default: None)
        follow_links: Whether to follow links on the page (default: True)
        
    Returns:
        Extracted content from the crawled pages
    """
    logger.info(f"Crawling website: {url}")
    logger.debug(f"Crawl parameters - depth: {depth}, max_pages: {max_pages}, selectors: {css_selectors}")
    
    try:
        # Create crawl configuration
        config = {
            "max_depth": depth,
            "max_pages": max_pages,
            "follow_links": follow_links,
            "wait_time": wait_time
        }
        
        # Run the async crawler using asyncio
        formatted_results = asyncio.run(_crawl_async(url, config, css_selectors))
        
        logger.info(f"Crawl completed: {len(formatted_results)} pages processed")
        
        # If only one page was crawled, return just that page's content
        if len(formatted_results) == 1:
            return formatted_results[0]["content"]
        
        return formatted_results
        
    except Exception as e:
        error_message = f"Error crawling {url}: {str(e)}"
        logger.error(error_message)
        return error_message 

async def _crawl_async(url: str, config: Dict[str, Any], css_selectors: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Async function to crawl a website using AsyncWebCrawler"""
    formatted_results = []
    
    try:
        # Create an instance of AsyncWebCrawler
        async with AsyncWebCrawler() as crawler:
            # If we're only fetching one page (depth 1, no link following)
            if config.get("max_depth", 1) == 1 or not config.get("follow_links", True):
                # Run single page crawl
                result = await crawler.arun(
                    url=url,
                    css_selectors=css_selectors,
                    max_depth=1,  # Force depth 1 for single page
                    max_pages=1,  # Force max_pages 1 for single page
                    follow_links=False,  # Don't follow links in single page mode
                    wait_time=config.get("wait_time", 0.5)
                )
                formatted_results.append(_format_result(result, url, css_selectors))
            else:
                # For deep crawling, use arun directly with all parameters
                # since arun_many has different parameters in crawl4ai
                result = await crawler.arun(
                    url=url,
                    css_selectors=css_selectors,
                    max_depth=config.get("max_depth", 1),
                    max_pages=config.get("max_pages", 5),
                    follow_links=config.get("follow_links", True),
                    wait_time=config.get("wait_time", 0.5)
                )
                # First page
                formatted_results.append(_format_result(result, url, css_selectors))
                
                # If links were found and we have results, process them
                if hasattr(result, 'links') and result.links:
                    # Extract all links
                    all_links = []
                    if isinstance(result.links, dict):
                        if 'internal' in result.links:
                            all_links.extend([link.get('href') for link in result.links['internal'] 
                                            if isinstance(link, dict) and 'href' in link])
                        if 'external' in result.links and not url.startswith("http://localhost"):
                            # Only include external links if not on localhost
                            all_links.extend([link.get('href') for link in result.links['external'] 
                                            if isinstance(link, dict) and 'href' in link])
                    elif isinstance(result.links, list):
                        all_links = result.links
                    
                    # Limit the number of additional pages to crawl
                    remaining_pages = config.get("max_pages", 5) - 1  # -1 for the first page
                    if remaining_pages > 0 and all_links:
                        # Only take the first few links based on remaining pages
                        links_to_crawl = all_links[:remaining_pages]
                        logger.info(f"Found {len(all_links)} links, crawling {len(links_to_crawl)} additional pages")
                        
                        # Crawl each link individually to have more control
                        for link in links_to_crawl:
                            try:
                                link_result = await crawler.arun(
                                    url=link,
                                    css_selectors=css_selectors,
                                    max_depth=1,  # We're manually handling depth
                                    max_pages=1,  # One page at a time
                                    follow_links=False,  # Don't follow links from this page
                                    wait_time=config.get("wait_time", 0.5)
                                )
                                formatted_results.append(_format_result(link_result, link, css_selectors))
                            except Exception as e:
                                logger.warning(f"Error crawling linked page {link}: {str(e)}")
                                # Continue with other links even if one fails
    except Exception as e:
        logger.error(f"Error in _crawl_async: {str(e)}")
        raise e
    
    return formatted_results

def _format_result(result, url, css_selectors):
    """Format a single crawl result into a dictionary"""
    formatted_page = {
        "url": url if not hasattr(result, 'url') else result.url,
        "content": result.markdown if hasattr(result, 'markdown') and result.markdown else 
                (result.text if hasattr(result, 'text') else "No content available"),
    }
    
    # Add HTML content if available
    if hasattr(result, 'html') and result.html:
        formatted_page["html"] = result.html[:1000] + "..." if len(result.html) > 1000 else result.html
    
    # Add links if available
    if hasattr(result, 'links') and result.links:
        # Links may be a dictionary with 'internal' and 'external' keys
        if isinstance(result.links, dict):
            all_links = []
            if 'internal' in result.links:
                all_links.extend([link.get('href') for link in result.links['internal'] if isinstance(link, dict) and 'href' in link])
            if 'external' in result.links:
                all_links.extend([link.get('href') for link in result.links['external'] if isinstance(link, dict) and 'href' in link])
            formatted_page["links"] = all_links
        else:
            formatted_page["links"] = result.links
    
    # Add extracted content from selectors if provided
    if css_selectors and hasattr(result, 'extracted_content') and result.extracted_content:
        formatted_page["extracted"] = result.extracted_content
    
    return formatted_page 