"""
Search tool implementation
"""

import os
import logging
from typing import Dict, Any, List

from langchain_core.tools import tool

logger = logging.getLogger(__name__)

@tool
def search_tool(query: str) -> List[Dict[str, str]]:
    """Search the web for information on the given query.
    
    Args:
        query: The search query
        
    Returns:
        A list of search results, each containing title, content, and URL
    """
    logger.info(f"Searching for: {query}")
    
    # Mock implementation (in a real system, this would call a search API)
    results = [
        {
            "title": "Mock search result 1",
            "content": f"This is a mock result for the query: {query}",
            "url": "https://example.com/result1"
        },
        {
            "title": "Mock search result 2",
            "content": f"Another mock result for: {query}",
            "url": "https://example.com/result2"
        }
    ]
    
    logger.debug(f"Found {len(results)} results for query: {query}")
    return results 