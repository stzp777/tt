"""
File handling tools for reading, writing, and managing files
"""

import os
import json
import logging
from pathlib import Path
from typing import Union, List, Dict, Any, Optional, Callable

from langchain_core.tools import tool, BaseTool
from langchain_community.agent_toolkits import FileManagementToolkit

logger = logging.getLogger(__name__)

# Initialize FileManagementToolkit with a root directory for security
def get_file_toolkit(root_dir: str = None) -> List[BaseTool]:
    """Get file management tools from LangChain's FileManagementToolkit.
    
    Args:
        root_dir: Optional root directory to restrict file operations to
                 If None, the current working directory will be used
    
    Returns:
        List of file management tool instances
    """
    # Set root directory to current working directory if not specified
    if root_dir is None:
        root_dir = os.getcwd()
    
    # Create the directory if it doesn't exist
    os.makedirs(root_dir, exist_ok=True)
    
    logger.info(f"Initializing FileManagementToolkit with root directory: {root_dir}")
    
    try:
        # Get tools from FileManagementToolkit
        toolkit = FileManagementToolkit(root_dir=root_dir)
        return toolkit.get_tools()
    except Exception as e:
        logger.error(f"Error initializing FileManagementToolkit: {str(e)}")
        return []

# Create custom implementations for all file tools to ensure consistent behavior

@tool("read_file")
def read_file_tool(file_path: str) -> str:
    """Read content from a file
    
    Args:
        file_path: Path to the file to read
        
    Returns:
        The content of the file as a string
    """
    try:
        logger.info(f"Reading file: {file_path}")
        file_path = os.path.expanduser(file_path)
        
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
        logger.info(f"Successfully read {len(content)} characters from {file_path}")
        return content
    except Exception as e:
        error_message = f"Error reading file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("write_file")
def write_file_tool(file_path: str, content: str, mode: str = "w") -> str:
    """Write content to a file
    
    Args:
        file_path: Path to the file to write
        content: Content to write to the file
        mode: Write mode - "w" for write (default, overwrites file), "a" for append
        
    Returns:
        Confirmation message
    """
    try:
        logger.info(f"Writing to file: {file_path} with mode: {mode}")
        file_path = os.path.expanduser(file_path)
        
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
        
        with open(file_path, mode, encoding='utf-8') as file:
            file.write(content)
            
        logger.info(f"Successfully wrote {len(content)} characters to {file_path}")
        return f"Successfully wrote content to {file_path}"
    except Exception as e:
        error_message = f"Error writing to file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("append_file")
def append_file_tool(file_path: str, content: str) -> str:
    """Append content to a file
    
    Args:
        file_path: Path to the file to append to
        content: Content to append to the file
        
    Returns:
        Confirmation message
    """
    try:
        logger.info(f"Appending to file: {file_path}")
        file_path = os.path.expanduser(file_path)
        
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
        
        with open(file_path, 'a', encoding='utf-8') as file:
            file.write(content)
            
        logger.info(f"Successfully appended {len(content)} characters to {file_path}")
        return f"Successfully appended content to {file_path}"
    except Exception as e:
        error_message = f"Error appending to file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("file_exists")
def file_exists_tool(file_path: str) -> bool:
    """Check if a file exists
    
    Args:
        file_path: Path to the file to check
        
    Returns:
        True if the file exists, False otherwise
    """
    try:
        logger.info(f"Checking if file exists: {file_path}")
        file_path = os.path.expanduser(file_path)
        
        exists = os.path.exists(file_path)
        is_file = os.path.isfile(file_path) if exists else False
        
        logger.info(f"File {file_path} exists: {exists and is_file}")
        return exists and is_file
    except Exception as e:
        logger.error(f"Error checking if file exists {file_path}: {str(e)}")
        return False

@tool("list_directory")
def list_directory_tool(directory_path: str) -> List[Dict[str, Any]]:
    """List files and directories at the given path
    
    Args:
        directory_path: Path to the directory to list
        
    Returns:
        List of dictionaries containing file/directory info:
        [{"name": "filename.txt", "type": "file", "size": 1234}, ...]
    """
    try:
        logger.info(f"Listing directory: {directory_path}")
        directory_path = os.path.expanduser(directory_path)
        
        if not os.path.exists(directory_path):
            return f"Directory {directory_path} does not exist"
            
        if not os.path.isdir(directory_path):
            return f"{directory_path} is not a directory"
            
        result = []
        
        for item in os.listdir(directory_path):
            item_path = os.path.join(directory_path, item)
            
            # Get item type and size
            item_type = "directory" if os.path.isdir(item_path) else "file"
            size = os.path.getsize(item_path) if os.path.isfile(item_path) else None
            
            # Get last modified time
            modified = os.path.getmtime(item_path)
            
            # Add item info to result
            result.append({
                "name": item,
                "type": item_type,
                "size": size,
                "modified": modified
            })
            
        logger.info(f"Found {len(result)} items in {directory_path}")
        return result
    except Exception as e:
        error_message = f"Error listing directory {directory_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("save_json")
def save_json_tool(file_path: str, data: Union[Dict, List]) -> str:
    """Save data as JSON file
    
    Args:
        file_path: Path to save the JSON file
        data: Data to save (must be JSON-serializable)
        
    Returns:
        Confirmation message
    """
    try:
        logger.info(f"Saving JSON to file: {file_path}")
        file_path = os.path.expanduser(file_path)
        
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=2)
            
        logger.info(f"Successfully saved JSON data to {file_path}")
        return f"Successfully saved JSON data to {file_path}"
    except Exception as e:
        error_message = f"Error saving JSON to file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("load_json")
def load_json_tool(file_path: str) -> Union[Dict, List]:
    """Load data from JSON file
    
    Args:
        file_path: Path to the JSON file to load
        
    Returns:
        The loaded JSON data
    """
    try:
        logger.info(f"Loading JSON from file: {file_path}")
        file_path = os.path.expanduser(file_path)
        
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
            
        logger.info(f"Successfully loaded JSON data from {file_path}")
        return data
    except Exception as e:
        error_message = f"Error loading JSON from file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("read_markdown")
def read_markdown_tool(file_path: str) -> str:
    """Read content from a markdown file
    
    Args:
        file_path: Path to the markdown file to read
        
    Returns:
        The content of the markdown file as a string
    """
    try:
        logger.info(f"Reading markdown file: {file_path}")
        # Just using the standard read_file functionality
        return read_file_tool.invoke({"file_path": file_path})
    except Exception as e:
        error_message = f"Error reading markdown file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("write_markdown")
def write_markdown_tool(file_path: str, content: str) -> str:
    """Write content to a markdown file
    
    Args:
        file_path: Path to the markdown file to write
        content: Markdown content to write to the file
        
    Returns:
        Confirmation message
    """
    try:
        logger.info(f"Writing markdown file: {file_path}")
        # Ensure file has .md extension
        if not file_path.lower().endswith('.md'):
            file_path += '.md'
        
        # Using the standard write_file functionality
        return write_file_tool.invoke({"file_path": file_path, "content": content})
    except Exception as e:
        error_message = f"Error writing markdown file {file_path}: {str(e)}"
        logger.error(error_message)
        return error_message

@tool("extract_markdown_sections")
def extract_markdown_sections_tool(content: str) -> Dict[str, str]:
    """Extract sections from markdown content based on headings
    
    Args:
        content: Markdown content to extract sections from
        
    Returns:
        Dictionary with heading names as keys and section content as values
    """
    try:
        logger.info("Extracting sections from markdown content")
        
        lines = content.split('\n')
        sections = {}
        current_section = None
        current_content = []
        current_level = 0
        
        for line in lines:
            # Check if line is a heading
            if line.strip().startswith('#'):
                # If we were already in a section, save it
                if current_section is not None:
                    sections[current_section] = '\n'.join(current_content).strip()
                
                # Extract heading level and name
                heading_parts = line.strip().split(' ', 1)
                if len(heading_parts) > 1:
                    level = len(heading_parts[0])
                    heading = heading_parts[1].strip()
                    
                    # Start new section
                    current_section = heading
                    current_level = level
                    current_content = []
                else:
                    # Empty heading, continue with current section
                    current_content.append(line)
            else:
                # Add line to current section content
                if current_section is not None:
                    current_content.append(line)
                else:
                    # No section yet, check if this is non-empty content
                    if line.strip():
                        sections['intro'] = line.strip()
        
        # Add the last section
        if current_section is not None:
            sections[current_section] = '\n'.join(current_content).strip()
            
        logger.info(f"Extracted {len(sections)} sections from markdown content")
        return sections
    except Exception as e:
        error_message = f"Error extracting markdown sections: {str(e)}"
        logger.error(error_message)
        return {"error": error_message} 