"""
Prompts module for the multi-agent LLM system
"""

from .template import apply_prompt_template 