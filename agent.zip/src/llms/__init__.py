"""
LLM interface module
""" 