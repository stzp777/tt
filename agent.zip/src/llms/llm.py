"""
LLM interface for different model types
"""

import os
from typing import Literal, Union, Dict, Any
from functools import lru_cache
import logging

from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI

from src.config.agents import DEFAULT_REASONING_MODEL, DEFAULT_BASIC_MODEL

logger = logging.getLogger(__name__)

# LLM type definitions
LLMType = Literal["reasoning", "basic"]

@lru_cache(maxsize=3)  # Cache the LLM instances
def get_llm_by_type(llm_type: Union[LLMType, str]) -> BaseChatModel:
    """Get an LLM instance based on the specified type.
    
    Args:
        llm_type: Type of LLM to get ("reasoning" or "basic")
        
    Returns:
        A configured LLM instance
    """
    llm_configs = {
        "reasoning": {
            "model": os.getenv("REASONING_MODEL", DEFAULT_REASONING_MODEL),
            "api_key": os.getenv("REASONING_API_KEY", os.getenv("OPENAI_API_KEY")),
            "base_url": os.getenv("REASONING_BASE_URL", os.getenv("OPENAI_BASE_URL")),
        },
        "basic": {
            "model": os.getenv("BASIC_MODEL", DEFAULT_BASIC_MODEL),
            "api_key": os.getenv("BASIC_API_KEY", os.getenv("OPENAI_API_KEY")),
            "base_url": os.getenv("BASIC_BASE_URL", os.getenv("OPENAI_BASE_URL")),
        },
    }
    
    if llm_type not in llm_configs:
        logger.warning(f"Unknown LLM type: {llm_type}. Falling back to basic.")
        llm_type = "basic"
    
    config = llm_configs[llm_type]
    logger.debug(f"Creating {llm_type} LLM with model: {config['model']}")
    
    # Filter out None values to avoid passing empty parameters
    filtered_config = {k: v for k, v in config.items() if v is not None}
    
    # Create and return LLM instance
    return ChatOpenAI(
        temperature=0.1,  # Low temperature for more deterministic responses
        **filtered_config
    ) 