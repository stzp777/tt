#!/usr/bin/env python
"""
Example of using the crawl tool to extract content from a website
"""

import sys
import os
import logging
import json
from dotenv import load_dotenv

# Add the project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

from src.tools import crawl_tool

def main():
    """Run the crawl tool example"""
    if len(sys.argv) < 2:
        print("Usage: python crawl_example.py <url> [depth] [max_pages]")
        sys.exit(1)
    
    url = sys.argv[1]
    depth = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    max_pages = int(sys.argv[3]) if len(sys.argv) > 3 else 3
    
    print(f"Crawling {url} with depth {depth} and max_pages {max_pages}...")
    
    # Use invoke method and pass parameters as a dictionary
    result = crawl_tool.invoke({
        "url": url,
        "depth": depth,
        "max_pages": max_pages,
        "wait_time": 1.0,
        "css_selectors": ["h1", "h2", "p.content", "div.main-content"],
        "follow_links": True
    })
    
    if isinstance(result, list):
        print(f"Crawled {len(result)} pages:")
        for i, page in enumerate(result):
            print(f"\nPage {i+1}: {page['url']}")
            
            # Print content snippet
            content = page.get('content', 'No content available')
            print(f"Content snippet: {content[:200]}..." if len(content) > 200 else content)
            
            # Print links if available
            if 'links' in page and page['links']:
                print(f"Links found: {len(page['links'])}")
                
            # Print extracted content if available
            if 'extracted' in page:
                print("Extracted content:")
                for selector, content in page['extracted'].items():
                    snippet = content[:100] + "..." if len(content) > 100 else content
                    print(f"  {selector}: {snippet}")
    else:
        print("Crawled content:")
        print(result[:1000] + "..." if len(result) > 1000 else result)

if __name__ == "__main__":
    main() 