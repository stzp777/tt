#!/usr/bin/env python
"""
Example of using the file handling tools to read, write, and manage files
"""

import sys
import os
import logging
import json
from dotenv import load_dotenv

# Add the project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

from src.tools import (
    read_file_tool,
    write_file_tool,
    append_file_tool,
    file_exists_tool,
    list_directory_tool,
    save_json_tool,
    load_json_tool,
    read_markdown_tool,
    write_markdown_tool,
    extract_markdown_sections_tool
)

def main():
    """Run the file tools example"""
    # Create a temporary directory for our examples
    temp_dir = "temp_examples"
    os.makedirs(temp_dir, exist_ok=True)
    
    print(f"Created temporary directory: {temp_dir}")
    
    # Example 1: Write to a file
    test_file = os.path.join(temp_dir, "test.txt")
    content = "Hello, world!\nThis is a test file."
    
    print("\n1. Writing to a file:")
    result = write_file_tool.invoke({
        "file_path": test_file, 
        "content": content
    })
    print(result)
    
    # Example 2: Read from a file
    print("\n2. Reading from a file:")
    read_result = read_file_tool.invoke({
        "file_path": test_file
    })
    print(f"File content: {read_result}")
    
    # Example 3: Append to a file
    print("\n3. Appending to a file:")
    append_result = append_file_tool.invoke({
        "file_path": test_file,
        "content": "\nThis content was appended."
    })
    print(append_result)
    
    # Read the file again to verify
    updated_content = read_file_tool.invoke({
        "file_path": test_file
    })
    print(f"Updated file content: {updated_content}")
    
    # Example 4: Check if a file exists
    print("\n4. Checking if files exist:")
    exists_result = file_exists_tool.invoke({
        "file_path": test_file
    })
    print(f"File {test_file} exists: {exists_result}")
    
    non_existent_file = os.path.join(temp_dir, "non_existent.txt")
    exists_result = file_exists_tool.invoke({
        "file_path": non_existent_file
    })
    print(f"File {non_existent_file} exists: {exists_result}")
    
    # Example 5: List directory contents
    print("\n5. Listing directory contents:")
    list_result = list_directory_tool.invoke({
        "directory_path": temp_dir
    })
    print(f"Contents of {temp_dir}:")
    for item in list_result:
        item_type = item["type"]
        size = f"{item['size']} bytes" if item["size"] is not None else "N/A"
        print(f"  - {item['name']} ({item_type}, {size})")
    
    # Example 6: Save and load JSON data
    print("\n6. Saving and loading JSON data:")
    json_file = os.path.join(temp_dir, "data.json")
    json_data = {
        "name": "Example Data",
        "values": [1, 2, 3, 4, 5],
        "nested": {
            "key": "value",
            "list": ["a", "b", "c"]
        }
    }
    
    # Save JSON data
    save_result = save_json_tool.invoke({
        "file_path": json_file,
        "data": json_data
    })
    print(save_result)
    
    # Load JSON data
    load_result = load_json_tool.invoke({
        "file_path": json_file
    })
    print(f"Loaded JSON data: {json.dumps(load_result, indent=2)}")
    
    # Example 7: Working with markdown files
    print("\n7. Working with markdown files:")
    
    # Create markdown content with sections
    markdown_content = """# Sample Markdown Document
    
This is an introduction paragraph.

## Section 1

This is the content of section 1.
- Point 1
- Point 2

## Section 2

This is the content of section 2.
1. Numbered item 1
2. Numbered item 2

### Subsection 2.1

This is a subsection.

## Section 3

Final section with some code:

```python
def hello_world():
    print("Hello, world!")
```
"""
    
    # Write markdown file
    markdown_file = os.path.join(temp_dir, "sample.md")
    write_result = write_markdown_tool.invoke({
        "file_path": markdown_file,
        "content": markdown_content
    })
    print(write_result)
    
    # Read markdown file
    read_md_result = read_markdown_tool.invoke({
        "file_path": markdown_file
    })
    print(f"Markdown content length: {len(read_md_result)} characters")
    
    # Extract sections from markdown
    sections_result = extract_markdown_sections_tool.invoke({
        "content": read_md_result
    })
    
    print("Extracted markdown sections:")
    for section, content in sections_result.items():
        print(f"  - {section}: {len(content)} characters")
        # Print the first 50 chars of each section
        print(f"    {content[:50]}..." if len(content) > 50 else content)

    print("\nExample completed successfully!")

if __name__ == "__main__":
    main() 