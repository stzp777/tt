# Market Regime Analysis

This project implements a comprehensive market regime classification system that analyzes various market states across multiple dimensions including volatility, correlation, interest rates, inflation, growth, and more.

## Features

Classifies market regimes across multiple categories:
1. Volatility (Low/Mid/High)
2. Equity-Bond Correlation
3. Interest Rate Regime
4. Inflation Regime
5. Growth Regime
6. Credit Cycle
7. Market Price Trends
8. Monetary Policy
9. Emerging Markets
10. Market Liquidity
11. Commodity Cycles
12. Currency Regimes
13. Market Sentiment
14. Trade Policy

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
Create a `.env` file with your API keys:
```
FRED_API_KEY=your_fred_api_key
```

## Usage

1. Data Collection:
```bash
python src/data_collection.py
```

2. Regime Classification:
```bash
python src/regime_classifier.py
```

## Project Structure

- `src/`: Source code
  - `data_collection.py`: Scripts for downloading and preprocessing data
  - `regime_classifier.py`: Main regime classification logic
  - `indicators/`: Individual regime indicators and calculations
  - `utils/`: Utility functions
- `data/`: Stored data files
- `notebooks/`: Jupyter notebooks for analysis and visualization
- `tests/`: Unit tests

## Data Sources

- FRED (Federal Reserve Economic Data)
- Yahoo Finance
- World Bank
- IMF Data 