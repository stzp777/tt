import pandas as pd
import os
from loguru import logger
import sys
from datetime import datetime

# Add src directory to path
sys.path.append('src')

# Import our modules
from data_collection import DataCollector
from regime_classifier import RegimeClassifier

def test_regime_classifier():
    """
    Test the RegimeClassifier by:
    1. Loading market data
    2. Initializing the classifier
    3. Classifying all regimes
    4. Getting current regimes
    5. Getting historical timeline
    6. Saving regime classifications
    """
    logger.info("Starting regime classifier test")
    
    # Check if market data exists, if not collect it
    data_path = 'data/market_data.csv'
    if not os.path.exists(data_path):
        logger.info("Market data not found. Collecting data...")
        collector = DataCollector()
        market_data = collector.collect_all_data()
    else:
        logger.info(f"Loading market data from {data_path}")
        market_data = pd.read_csv(data_path, index_col=0, parse_dates=True)
    
    # Initialize the regime classifier
    logger.info("Initializing regime classifier")
    classifier = RegimeClassifier(market_data)
    
    # Test individual regime classifications
    logger.info("Testing individual regime classifications")
    try:
        volatility_regime = classifier.classify_volatility_regime()
        logger.success(f"Volatility regime classification successful: {volatility_regime.iloc[-1]}")
        
        inflation_regime = classifier.classify_inflation_regime()
        logger.success(f"Inflation regime classification successful: {inflation_regime.iloc[-1]}")
        
        growth_regime = classifier.classify_growth_regime()
        logger.success(f"Growth regime classification successful: {growth_regime.iloc[-1]}")
    except Exception as e:
        logger.error(f"Error in individual regime classification: {str(e)}")
    
    # Classify all regimes
    logger.info("Classifying all regimes")
    try:
        all_regimes = classifier.classify_all_regimes()
        logger.success(f"Successfully classified {len(all_regimes)} regime types")
    except Exception as e:
        logger.error(f"Error classifying all regimes: {str(e)}")
        return
    
    # Get current regimes
    logger.info("Getting current regimes")
    try:
        current_regimes = classifier.get_current_regimes()
        logger.success("Current regime classifications:")
        for regime_type, regime_value in current_regimes.items():
            logger.info(f"  {regime_type}: {regime_value}")
    except Exception as e:
        logger.error(f"Error getting current regimes: {str(e)}")
    
    # Get historical timeline
    logger.info("Getting historical timeline")
    try:
        timeline = classifier.get_historical_timeline(start_date='2000-01-01')
        logger.success(f"Successfully retrieved historical timeline from {timeline.index[0]} to {timeline.index[-1]}")
        logger.info(f"Timeline shape: {timeline.shape}")
    except Exception as e:
        logger.error(f"Error getting historical timeline: {str(e)}")
    
    # Save regime classifications
    logger.info("Saving regime classifications")
    try:
        output_path = f'data/regime_classifications_{datetime.now().strftime("%Y%m%d")}.csv'
        monthly_regimes = classifier.save_regimes(output_path=output_path)
        logger.success(f"Successfully saved regime classifications to {output_path}")
        
        # Display summary statistics
        logger.info("Regime frequency summary:")
        for column in monthly_regimes.columns:
            value_counts = monthly_regimes[column].value_counts(normalize=True) * 100
            logger.info(f"  {column}:")
            for regime_value, percentage in value_counts.items():
                logger.info(f"    {regime_value}: {percentage:.1f}%")
    except Exception as e:
        logger.error(f"Error saving regime classifications: {str(e)}")
    
    logger.info("Regime classifier test completed")

if __name__ == "__main__":
    # Configure logger
    logger.remove()
    logger.add(
        sys.stdout,
        format="{time:HH:mm:ss} | {level} | {message}",
        level="INFO",
        colorize=True
    )
    logger.add(
        "logs/test_regime_classifier_{time}.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
        level="DEBUG"
    )
    
    # Run the test
    test_regime_classifier() 