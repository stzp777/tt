import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from scipy import stats
import logging
from typing import Dict, List, Tuple

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RegimeClassifier:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.regimes = {}
        
    def classify_volatility_regime(self, window: int = 20) -> pd.Series:
        """
        Classify volatility regime using VIX levels
        """
        vix = self.data['VIXCLS']
        regimes = pd.Series(index=vix.index, data='mid')
        regimes[vix > vix.quantile(0.75)] = 'high'
        regimes[vix < vix.quantile(0.25)] = 'low'
        return regimes

    def classify_correlation_regime(self, window: int = 60) -> pd.Series:
        """
        Classify equity-bond correlation regime
        """
        spy_returns = self.data['SPY_Close'].pct_change(fill_method=None)
        tlt_returns = self.data['TLT_Close'].pct_change(fill_method=None)
        rolling_corr = spy_returns.rolling(window).corr(tlt_returns)
        return pd.Series(index=rolling_corr.index, data=np.where(rolling_corr > 0, 'positive', 'negative'))

    def classify_interest_rate_regime(self, window: int = 20) -> pd.Series:
        """
        Classify interest rate regime based on Fed Funds rate changes
        """
        fed_rate = self.data['FEDFUNDS']
        rate_change = fed_rate.diff(periods=window)
        return pd.Series(index=rate_change.index, data=np.where(rate_change > 0, 'hike', 'cut'))

    def classify_inflation_regime(self, window: int = 12) -> pd.Series:
        """
        Classify inflation regime using OECD CPI YoY changes
        """
        cpi = self.data['OECD_CPI']
        # Calculate year-over-year CPI change
        inflation_yoy = cpi.pct_change(periods=12, fill_method=None) * 100
        # Calculate 3-month change in inflation to determine trend
        inflation_trend = inflation_yoy.diff(periods=3)
        return pd.Series(index=inflation_yoy.index, data=np.where(inflation_trend > 0, 'rising', 'falling'))

    def classify_growth_regime(self, window: int = 3) -> pd.Series:
        """
        Classify growth regime using OECD CLI (Composite Leading Indicator)
        CLI > 100 indicates expansion, < 100 indicates contraction
        Also consider the trend over the last 3 months
        """
        cli = self.data['OECD_CLI']
        cli_trend = cli.diff(periods=window)
        
        regimes = pd.Series(index=cli.index, data='falling')
        rising_mask = (cli_trend > 0) & (cli > 100)
        regimes[rising_mask] = 'rising'
        return regimes

    def classify_credit_cycle(self) -> pd.Series:
        """
        Classify credit cycle using High Yield spread
        """
        hy_spread = self.data['BAMLH0A0HYM2']
        return pd.Series(index=hy_spread.index, data=np.where(hy_spread < hy_spread.mean(), 'expansion', 'contraction'))

    def classify_market_price_regime(self, window: int = 20) -> pd.Series:
        """
        Classify market price regime using trend and volatility
        """
        spy_price = self.data['SPY_Close']
        returns = spy_price.pct_change(fill_method=None)
        volatility = returns.rolling(window).std()
        trend = spy_price.rolling(window).mean()
        
        regimes = pd.Series(index=spy_price.index, data='whipsaw')
        trending_mask = (volatility < volatility.mean()) & (abs(returns.rolling(window).mean()) > returns.std())
        regimes[trending_mask] = 'trending'
        return regimes

    def classify_monetary_policy(self) -> pd.Series:
        """
        Classify monetary policy using Fed Funds rate and M2
        """
        fed_rate = self.data['FEDFUNDS']
        m2_growth = self.data['M2SL'].pct_change(periods=12, fill_method=None)
        
        regimes = pd.Series(index=fed_rate.index, data='neutral')
        tightening_mask = (fed_rate.diff() > 0) & (m2_growth < m2_growth.mean())
        easing_mask = (fed_rate.diff() < 0) & (m2_growth > m2_growth.mean())
        
        regimes[tightening_mask] = 'tightening'
        regimes[easing_mask] = 'easing'
        return regimes

    def classify_em_regime(self) -> pd.Series:
        """
        Classify emerging markets regime
        """
        em_returns = self.data['EEM_Close'].pct_change(periods=60, fill_method=None)
        return pd.Series(index=em_returns.index, data=np.where(em_returns > 0, 'growth', 'recession'))

    def classify_market_liquidity(self, window: int = 20) -> pd.Series:
        """
        Classify market liquidity using volume and spread data
        """
        volume = self.data['SPY_Volume']
        hy_spread = self.data['BAMLH0A0HYM2']
        
        vol_z_score = (volume - volume.rolling(window).mean()) / volume.rolling(window).std()
        spread_z_score = (hy_spread - hy_spread.rolling(window).mean()) / hy_spread.rolling(window).std()
        
        liquidity_score = vol_z_score - spread_z_score
        return pd.Series(index=volume.index, data=np.where(liquidity_score > 0, 'high', 'low'))

    def classify_commodity_regime(self) -> pd.Series:
        """
        Classify commodity regime
        """
        commodity_price = self.data['DBC_Close']
        returns_12m = commodity_price.pct_change(periods=252, fill_method=None)
        return pd.Series(index=commodity_price.index, data=np.where(returns_12m > 0, 'boom', 'bust'))

    def classify_currency_regime(self) -> pd.Series:
        """
        Classify USD regime
        """
        usd_index = self.data['DTWEXB']
        strength = usd_index.rolling(60).mean()
        return pd.Series(index=usd_index.index, data=np.where(strength > strength.shift(1), 'strong', 'weak'))

    def classify_market_sentiment(self, window: int = 20) -> pd.Series:
        """
        Classify market sentiment using multiple indicators
        """
        vix = self.data['VIXCLS']
        hy_spread = self.data['BAMLH0A0HYM2']
        spy_returns = self.data['SPY_Close'].pct_change(periods=window, fill_method=None)
        
        # Combine indicators into sentiment score
        vix_z = (vix - vix.mean()) / vix.std()
        spread_z = (hy_spread - hy_spread.mean()) / hy_spread.std()
        returns_z = (spy_returns - spy_returns.mean()) / spy_returns.std()
        
        sentiment_score = -vix_z - spread_z + returns_z
        return pd.Series(index=vix.index, data=np.where(sentiment_score > 0, 'optimistic', 'pessimistic'))

    def classify_trade_policy(self) -> pd.Series:
        """
        Classify trade policy regime using market indicators
        """
        em_ratio = self.data['EEM_Close'] / self.data['SPY_Close']
        trade_score = em_ratio.rolling(60).mean()
        return pd.Series(index=em_ratio.index, data=np.where(trade_score > trade_score.shift(1), 'free', 'protectionism'))

    def classify_all_regimes(self) -> Dict[str, pd.Series]:
        """
        Classify all market regimes
        """
        self.regimes = {
            'volatility': self.classify_volatility_regime(),
            'correlation': self.classify_correlation_regime(),
            'interest_rate': self.classify_interest_rate_regime(),
            'inflation': self.classify_inflation_regime(),
            'growth': self.classify_growth_regime(),
            'credit': self.classify_credit_cycle(),
            'market_price': self.classify_market_price_regime(),
            'monetary_policy': self.classify_monetary_policy(),
            'emerging_markets': self.classify_em_regime(),
            'market_liquidity': self.classify_market_liquidity(),
            'commodity': self.classify_commodity_regime(),
            'currency': self.classify_currency_regime(),
            'sentiment': self.classify_market_sentiment(),
            'trade_policy': self.classify_trade_policy()
        }
        return self.regimes

    def get_current_regimes(self) -> Dict[str, str]:
        """
        Get the most recent regime classification for all categories
        """
        if not self.regimes:
            self.classify_all_regimes()
        
        current_regimes = {}
        for regime_type, regime_series in self.regimes.items():
            current_regimes[regime_type] = regime_series.iloc[-1]
        return current_regimes

    def save_regimes(self, output_path: str = 'data/regime_classifications.csv'):
        """
        Save all regime classifications to CSV
        """
        if not self.regimes:
            self.classify_all_regimes()
        
        regime_df = pd.DataFrame(self.regimes)
        
        # Ensure monthly frequency
        regime_df.index = pd.to_datetime(regime_df.index)
        monthly_regimes = regime_df.resample('ME').last()
        
        # Save both detailed and monthly data
        regime_df.to_csv(output_path)
        monthly_path = output_path.replace('.csv', '_monthly.csv')
        monthly_regimes.to_csv(monthly_path)
        
        logger.info(f"Regime classifications saved to {output_path}")
        logger.info(f"Monthly regime classifications saved to {monthly_path}")
        
        return monthly_regimes

    def get_historical_timeline(self, start_date: str = '1990-01-01') -> pd.DataFrame:
        """
        Get historical timeline of all regimes from start_date
        Returns a DataFrame with monthly frequency
        """
        if not self.regimes:
            self.classify_all_regimes()
            
        # Convert all regime series to a DataFrame
        regime_df = pd.DataFrame(self.regimes)
        regime_df.index = pd.to_datetime(regime_df.index)
        
        # Filter by start date and resample to monthly frequency
        historical_regimes = regime_df[regime_df.index >= start_date].resample('ME').last()
        
        # Add metadata
        historical_regimes.index.name = 'Date'
        
        # Calculate regime statistics
        stats = {}
        for column in historical_regimes.columns:
            value_counts = historical_regimes[column].value_counts()
            stats[column] = {
                'most_common': value_counts.index[0],
                'frequency': value_counts.iloc[0] / len(historical_regimes),
                'unique_regimes': len(value_counts)
            }
            
        logger.info("Historical Timeline Statistics:")
        for regime, stat in stats.items():
            logger.info(f"{regime}:")
            logger.info(f"  Most common: {stat['most_common']} ({stat['frequency']:.1%})")
            logger.info(f"  Unique regimes: {stat['unique_regimes']}")
        
        return historical_regimes

if __name__ == "__main__":
    # Load market data
    data = pd.read_csv('data/market_data.csv', index_col=0, parse_dates=True)
    
    # Initialize and run classifier
    classifier = RegimeClassifier(data)
    regimes = classifier.classify_all_regimes()
    
    # Get and save historical timeline
    historical_regimes = classifier.get_historical_timeline()
    historical_regimes.to_csv('data/historical_regimes_monthly.csv')
    
    # Save detailed regime classifications
    classifier.save_regimes()
    
    # Print current regimes
    current_regimes = classifier.get_current_regimes()
    print("\nCurrent Market Regimes:")
    for regime_type, regime in current_regimes.items():
        print(f"{regime_type}: {regime}")
        
    print("\nHistorical Timeline Summary:")
    print(f"Date range: {historical_regimes.index[0].strftime('%Y-%m')} to {historical_regimes.index[-1].strftime('%Y-%m')}")
    print(f"Number of months: {len(historical_regimes)}")
    print("\nRegime Frequencies:")
    for column in historical_regimes.columns:
        print(f"\n{column}:")
        print(historical_regimes[column].value_counts(normalize=True).round(3) * 100, "%") 