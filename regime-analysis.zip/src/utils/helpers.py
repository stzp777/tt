import pandas as pd
import numpy as np
from typing import Union, List, Tuple
from scipy import stats

def calculate_returns(prices: pd.Series, 
                     period: int = 1, 
                     log_returns: bool = False) -> pd.Series:
    """
    Calculate returns from price series
    """
    if log_returns:
        return np.log(prices / prices.shift(period))
    return prices.pct_change(periods=period)

def calculate_volatility(returns: pd.Series, 
                        window: int = 20, 
                        annualize: bool = True) -> pd.Series:
    """
    Calculate rolling volatility
    """
    vol = returns.rolling(window=window).std()
    if annualize:
        vol = vol * np.sqrt(252)
    return vol

def calculate_zscore(series: pd.Series, 
                    window: int = 20) -> pd.Series:
    """
    Calculate rolling z-score
    """
    mean = series.rolling(window=window).mean()
    std = series.rolling(window=window).std()
    return (series - mean) / std

def calculate_momentum(prices: pd.Series, 
                      period: int = 60) -> pd.Series:
    """
    Calculate price momentum
    """
    return prices / prices.shift(period) - 1

def calculate_drawdown(prices: pd.Series) -> pd.Series:
    """
    Calculate drawdown from peak
    """
    rolling_max = prices.expanding().max()
    drawdown = prices / rolling_max - 1
    return drawdown

def calculate_correlation(series1: pd.Series, 
                         series2: pd.Series, 
                         window: int = 60) -> pd.Series:
    """
    Calculate rolling correlation between two series
    """
    return series1.rolling(window=window).corr(series2)

def detect_regime_change(series: pd.Series, 
                        threshold: float = 2.0) -> pd.Series:
    """
    Detect regime changes using z-score threshold
    """
    zscore = calculate_zscore(series)
    regime_change = pd.Series(index=series.index, data=False)
    regime_change[abs(zscore) > threshold] = True
    return regime_change

def calculate_trend_strength(prices: pd.Series, 
                           window: int = 20) -> pd.Series:
    """
    Calculate trend strength using linear regression
    """
    returns = calculate_returns(prices)
    slope = pd.Series(index=returns.index, dtype=float)
    
    for i in range(window, len(returns)):
        y = returns.iloc[i-window:i].values
        x = np.arange(window)
        slope.iloc[i] = stats.linregress(x, y).slope
    
    return slope

def normalize_series(series: pd.Series, 
                    method: str = 'zscore') -> pd.Series:
    """
    Normalize time series data
    """
    if method == 'zscore':
        return (series - series.mean()) / series.std()
    elif method == 'minmax':
        return (series - series.min()) / (series.max() - series.min())
    else:
        raise ValueError("Method must be 'zscore' or 'minmax'")

def calculate_regime_transitions(regime_series: pd.Series) -> pd.DataFrame:
    """
    Calculate regime transition probabilities
    """
    transitions = pd.crosstab(regime_series.shift(), 
                            regime_series, 
                            normalize='index')
    return transitions

def combine_regime_signals(*signals: List[pd.Series], 
                         weights: List[float] = None) -> pd.Series:
    """
    Combine multiple regime signals into a single signal
    """
    if weights is None:
        weights = [1/len(signals)] * len(signals)
    
    combined = pd.concat(signals, axis=1)
    return (combined * weights).sum(axis=1)

def detect_outliers(series: pd.Series, 
                   n_std: float = 3.0) -> pd.Series:
    """
    Detect outliers using standard deviation
    """
    mean = series.mean()
    std = series.std()
    outliers = (series < (mean - n_std * std)) | (series > (mean + n_std * std))
    return outliers 