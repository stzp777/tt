import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from typing import Dict, List, Optional, Union

def plot_regime_timeline(regimes: pd.DataFrame,
                        title: str = "Market Regimes Timeline") -> go.Figure:
    """
    Create a timeline visualization of different regimes
    """
    fig = go.Figure()
    
    for col in regimes.columns:
        unique_regimes = regimes[col].unique()
        for regime in unique_regimes:
            mask = regimes[col] == regime
            fig.add_trace(
                go.Scatter(
                    x=regimes.index[mask],
                    y=[col] * mask.sum(),
                    mode='markers',
                    name=f"{col}: {regime}",
                    marker=dict(size=10),
                    hovertext=[regime] * mask.sum()
                )
            )
    
    fig.update_layout(
        title=title,
        yaxis_title="Regime Categories",
        xaxis_title="Date",
        showlegend=True,
        height=800
    )
    
    return fig

def plot_regime_transitions(regime_series: pd.Series,
                          title: str = "Regime Transitions") -> go.Figure:
    """
    Create a heatmap of regime transition probabilities
    """
    transitions = pd.crosstab(
        regime_series.shift(),
        regime_series,
        normalize='index'
    )
    
    fig = go.Figure(data=go.Heatmap(
        z=transitions.values,
        x=transitions.columns,
        y=transitions.index,
        colorscale='RdYlBu',
        text=np.round(transitions.values, 2),
        texttemplate='%{text}',
        textfont={"size": 10},
        hoverongaps=False
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="To Regime",
        yaxis_title="From Regime"
    )
    
    return fig

def plot_regime_distribution(regime_series: pd.Series,
                           title: str = "Regime Distribution") -> go.Figure:
    """
    Create a pie chart showing the distribution of regimes
    """
    distribution = regime_series.value_counts()
    
    fig = go.Figure(data=go.Pie(
        labels=distribution.index,
        values=distribution.values,
        textinfo='label+percent'
    ))
    
    fig.update_layout(title=title)
    return fig

def plot_regime_indicators(data: pd.DataFrame,
                         regime_series: pd.Series,
                         indicators: List[str],
                         title: str = "Regime Indicators") -> go.Figure:
    """
    Create a subplot showing indicators with regime backgrounds
    """
    n_indicators = len(indicators)
    fig = make_subplots(rows=n_indicators, cols=1,
                        shared_xaxes=True,
                        subplot_titles=indicators)
    
    unique_regimes = regime_series.unique()
    colors = px.colors.qualitative.Set3[:len(unique_regimes)]
    color_map = dict(zip(unique_regimes, colors))
    
    for i, indicator in enumerate(indicators, 1):
        # Plot indicator line
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data[indicator],
                name=indicator,
                line=dict(color='black')
            ),
            row=i, col=1
        )
        
        # Add colored backgrounds for regimes
        for regime in unique_regimes:
            mask = regime_series == regime
            if mask.any():
                fig.add_trace(
                    go.Scatter(
                        x=data.index[mask],
                        y=data[indicator][mask],
                        fill='tonexty',
                        mode='none',
                        name=f"{regime} regime",
                        fillcolor=f"rgba{tuple(list(px.colors.hex_to_rgb(color_map[regime])) + [0.2])}",
                        showlegend=i==1
                    ),
                    row=i, col=1
                )
    
    fig.update_layout(
        height=300 * n_indicators,
        title=title,
        showlegend=True
    )
    
    return fig

def plot_regime_summary(regimes: pd.DataFrame,
                       data: pd.DataFrame,
                       key_indicators: List[str]) -> go.Figure:
    """
    Create a comprehensive summary dashboard of all regimes
    """
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=[
            "Regime Timeline",
            "Current Regime Distribution",
            "Key Indicators",
            "Regime Transitions",
            "Regime Correlations",
            "Regime Statistics"
        ],
        specs=[[{"type": "scatter"}, {"type": "pie"}],
               [{"type": "scatter"}, {"type": "heatmap"}],
               [{"type": "table"}, {"type": "table"}]]
    )
    
    # Add regime timeline
    current_regimes = regimes.iloc[-1]
    for i, (regime_type, current_regime) in enumerate(current_regimes.items()):
        fig.add_trace(
            go.Scatter(
                x=regimes.index,
                y=[i] * len(regimes),
                mode='lines',
                name=regime_type,
                text=regimes[regime_type],
                hovertemplate="%{text}"
            ),
            row=1, col=1
        )
    
    # Add current distribution
    regime_counts = regimes.iloc[-1].value_counts()
    fig.add_trace(
        go.Pie(
            labels=regime_counts.index,
            values=regime_counts.values,
            textinfo='label+percent'
        ),
        row=1, col=2
    )
    
    # Add key indicators
    for indicator in key_indicators:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data[indicator],
                name=indicator
            ),
            row=2, col=1
        )
    
    # Add regime transitions heatmap
    transitions = pd.crosstab(
        regimes.iloc[-1],
        regimes.iloc[-2],
        normalize='index'
    )
    fig.add_trace(
        go.Heatmap(
            z=transitions.values,
            x=transitions.columns,
            y=transitions.index,
            colorscale='RdYlBu'
        ),
        row=2, col=2
    )
    
    # Add statistics table
    stats_df = pd.DataFrame({
        'Metric': ['Mean', 'Std', 'Min', 'Max'],
        'Value': [
            data[key_indicators].mean().mean(),
            data[key_indicators].std().mean(),
            data[key_indicators].min().mean(),
            data[key_indicators].max().mean()
        ]
    })
    
    fig.add_trace(
        go.Table(
            header=dict(values=list(stats_df.columns)),
            cells=dict(values=[stats_df[col] for col in stats_df.columns])
        ),
        row=3, col=1
    )
    
    fig.update_layout(
        height=1200,
        title="Market Regime Analysis Dashboard",
        showlegend=True
    )
    
    return fig

def plot_regime_correlation(regimes: pd.DataFrame) -> go.Figure:
    """
    Create a correlation matrix heatmap between different regime categories
    """
    # Convert regime categories to numeric
    numeric_regimes = pd.DataFrame()
    for col in regimes.columns:
        numeric_regimes[col] = pd.Categorical(regimes[col]).codes
    
    # Calculate correlation matrix
    corr_matrix = numeric_regimes.corr()
    
    fig = go.Figure(data=go.Heatmap(
        z=corr_matrix.values,
        x=corr_matrix.columns,
        y=corr_matrix.index,
        colorscale='RdBu',
        text=np.round(corr_matrix.values, 2),
        texttemplate='%{text}',
        textfont={"size": 10},
        hoverongaps=False
    ))
    
    fig.update_layout(
        title="Regime Category Correlations",
        xaxis_title="Regime Category",
        yaxis_title="Regime Category"
    )
    
    return fig 