import os
import pandas as pd
import yfinance as yf
from yahooquery import Ticker
from dotenv import load_dotenv
from datetime import datetime, timedelta
import requests
from loguru import logger
import pandas_datareader.data as pdr
import io

# Load environment variables
load_dotenv()
FRED_API_KEY = os.getenv('FRED_API_KEY')

# Configure loguru
logger.remove()  # Remove default handler
logger.add(
    "logs/data_collection_{time}.log",
    rotation="1 day",
    retention="1 month",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
    level="INFO",
    backtrace=True,
    diagnose=True
)
logger.add(
    lambda msg: print(msg),  # Also log to console
    format="{time:HH:mm:ss} | {level} | {message}",
    level="INFO",
    colorize=True
)

class DataCollector:
    def __init__(self):
        self.start_date = '1990-01-01'
        self.end_date = datetime.now().strftime('%Y-%m-%d')
        logger.info(f"Initialized DataCollector with date range: {self.start_date} to {self.end_date}")

    def get_fred_data(self, series_ids, transform=None):
        """
        Fetch data from FRED database using pandas_datareader
        """
        data = pd.DataFrame()
        for series_id in series_ids:
            try:
                logger.debug(f"Fetching {series_id} from FRED")
                series = pdr.DataReader(
                    series_id,
                    'fred',
                    start=self.start_date,
                    end=self.end_date
                )
                
                # Resample to monthly frequency if needed
                if not isinstance(series.index, pd.DatetimeIndex):
                    series.index = pd.to_datetime(series.index)
                if series.index.freq != 'ME':
                    series = series.resample('ME').last()
                
                # Rename column to series_id
                series.columns = [series_id]
                data[series_id] = series[series_id]
                logger.success(f"Successfully fetched {series_id} from FRED")
            except Exception as e:
                logger.exception(f"Error fetching {series_id}: {str(e)}")
        return data

    def get_oecd_data(self):
        """
        Fetch OECD data for CPI and CLI using SDMX REST API
        """
        # OECD SDMX REST API URLs with explicit format=csvfilewithlabels
        cli_url = "https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_STES@DF_CLI,/G20.M.LI...AA...H?dimensionAtObservation=AllDimensions&format=csvfilewithlabels"
        cpi_url = "https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0/OECD.M.N.CPI.._T.N.GY+_Z?startPeriod=1990-01&dimensionAtObservation=AllDimensions&format=csvfilewithlabels"

        data = pd.DataFrame()
        
        try:
            # Helper function to process OECD CSV response
            def process_oecd_csv(url, indicator_name):
                try:
                    logger.debug(f"Downloading {indicator_name} data")
                    
                    # Add headers to prevent blocking
                    headers = {
                        'User-Agent': 'Mozilla/5.0',
                        'Accept': 'text/csv',
                        'Accept-Encoding': 'gzip, deflate'
                    }
                    
                    # Download data
                    response = requests.get(url, headers=headers)
                    if response.status_code != 200:
                        logger.error(f"Failed to fetch {indicator_name}: Status code {response.status_code}")
                        logger.error(f"Response content: {response.text[:500]}")  # Log first 500 chars of response
                        return None
                    
                    # Create logs directory if it doesn't exist
                    os.makedirs('logs', exist_ok=True)
                    
                    # Save response to debug file
                    with open(f"logs/{indicator_name}_response.csv", "w") as f:
                        f.write(response.text)
                    logger.debug(f"Saved raw response to logs/{indicator_name}_response.csv")
                    
                    # Read CSV data
                    df = pd.read_csv(io.StringIO(response.text))
                    
                    # Log all column names for debugging
                    logger.debug(f"All columns in response: {df.columns.tolist()}")
                    
                    # Find the time period column - typically TIME_PERIOD
                    time_col = 'TIME_PERIOD'
                    if time_col not in df.columns:
                        time_cols = [col for col in df.columns if 'TIME' in col.upper() or 'PERIOD' in col.upper()]
                        if not time_cols:
                            logger.error(f"Could not find time period column in {indicator_name} data")
                            return None
                        time_col = time_cols[0]
                    
                    logger.debug(f"Using column '{time_col}' as time period for {indicator_name}")
                    
                    # Find the observation value column - typically OBS_VALUE
                    value_col = 'OBS_VALUE'
                    if value_col not in df.columns:
                        # Try common alternatives, prioritizing these over generic matches
                        potential_value_cols = ['Value', 'DATA_VALUE', 'OBSERVATION_VALUE']
                        for col in potential_value_cols:
                            if col in df.columns:
                                value_col = col
                                break
                        else:
                            # If none of the specific columns are found, look for any column with numbers
                            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
                            if numeric_cols:
                                # Exclude any columns that seem to be codes or IDs
                                numeric_cols = [col for col in numeric_cols if not any(x in col.upper() for x in ['CODE', 'ID', 'INDEX'])]
                                if numeric_cols:
                                    value_col = numeric_cols[0]
                                else:
                                    logger.error(f"Could not find suitable numeric value column in {indicator_name} data")
                                    return None
                            else:
                                logger.error(f"No numeric columns found in {indicator_name} data")
                                return None
                    
                    logger.debug(f"Using column '{value_col}' as observation value for {indicator_name}")
                    
                    # Verify the value column contains numeric data
                    sample_values = df[value_col].head().tolist()
                    logger.debug(f"Sample values from '{value_col}': {sample_values}")
                    
                    # Check if we need to convert to numeric (in case the column has mixed types)
                    if not pd.api.types.is_numeric_dtype(df[value_col]):
                        logger.warning(f"Converting non-numeric column '{value_col}' to numeric")
                        df[value_col] = pd.to_numeric(df[value_col], errors='coerce')
                        if df[value_col].isna().all():
                            logger.error(f"Failed to convert column '{value_col}' to numeric")
                            return None
                    
                    # Show sample of data for debugging
                    logger.debug(f"Sample data for {indicator_name}:\n{df[[time_col, value_col]].head().to_string()}")
                    
                    # Convert time column to datetime
                    try:
                        df[time_col] = pd.to_datetime(df[time_col])
                    except Exception as e:
                        logger.error(f"Error converting {time_col} to datetime: {str(e)}")
                        # Try a different format if standard parsing fails
                        try:
                            df[time_col] = pd.to_datetime(df[time_col], format='%Y-%m')
                        except Exception as e2:
                            logger.error(f"Error with alternative datetime format: {str(e2)}")
                            return None
                    
                    # Create series with proper index
                    series = df.set_index(time_col)[value_col]
                    series.name = indicator_name
                    
                    # Ensure monthly frequency and sort index
                    series = series.sort_index()
                    if series.index.freq != 'ME':
                        series = series.resample('ME').last()
                    
                    logger.debug(f"Processed {len(series)} observations for {indicator_name}")
                    logger.debug(f"Date range: {series.index.min()} to {series.index.max()}")
                    return series
                    
                except Exception as e:
                    logger.exception(f"Error processing {indicator_name} data: {str(e)}")
                    return None

            # Fetch CLI data first (Composite Leading Indicator)
            logger.debug("Fetching OECD CLI data")
            cli_series = process_oecd_csv(cli_url, 'OECD_CLI')
            if cli_series is not None:
                data['OECD_CLI'] = cli_series
                logger.success("Successfully fetched OECD CLI data")
            else:
                logger.warning("Failed to process OECD CLI data")
            
            # Fetch CPI data
            logger.debug("Fetching OECD CPI data")
            cpi_series = process_oecd_csv(cpi_url, 'OECD_CPI')
            if cpi_series is not None:
                data['OECD_CPI'] = cpi_series
                logger.success("Successfully fetched OECD CPI data")
            else:
                logger.warning("Failed to process OECD CPI data")
                
        except Exception as e:
            logger.exception(f"Error fetching OECD data: {str(e)}")
            
        if data.empty:
            logger.error("No OECD data was successfully collected")
        else:
            logger.info(f"Successfully collected OECD data with shape: {data.shape}")
            logger.debug(f"OECD data columns: {data.columns.tolist()}")
            logger.debug(f"OECD data date range: {data.index.min()} to {data.index.max()}")
            
        return data

    def get_market_data(self, tickers):
        """
        Fetch market data from Yahoo Finance using yahooquery
        """
        data = pd.DataFrame()
        
        try:
            # Create Ticker object for all tickers at once
            yq_tickers = Ticker(tickers, asynchronous=True)
            
            # Get history for all tickers
            logger.debug(f"Fetching data for tickers: {tickers}")
            history = yq_tickers.history(
                start=self.start_date,
                end=self.end_date,
                interval='1d'
            )
            
            if isinstance(history, str) or history.empty:
                logger.error("Failed to fetch market data")
                return data
            
            # Process each ticker's data
            for ticker in tickers:
                try:
                    # Filter data for current ticker
                    ticker_data = history.xs(ticker, level='symbol')
                    
                    if ticker_data.empty:
                        logger.warning(f"No data available for {ticker}")
                        continue
                    
                    # Ensure index is datetime
                    if not isinstance(ticker_data.index, pd.DatetimeIndex):
                        logger.debug(f"Converting index to datetime for {ticker}")
                        ticker_data.index = pd.to_datetime(ticker_data.index)
                    
                    # Resample to monthly frequency
                    monthly_data = ticker_data.resample('ME').agg({
                        'adjclose': 'last',
                        'volume': 'sum'
                    })
                    
                    # Add to data frame
                    data[f"{ticker}_Close"] = monthly_data['adjclose']
                    data[f"{ticker}_Volume"] = monthly_data['volume']
                    logger.success(f"Successfully processed {ticker} data")
                    
                except KeyError as e:
                    logger.warning(f"Missing columns for {ticker}: {str(e)}")
                    # Try alternative column names
                    try:
                        alternative_monthly = ticker_data.resample('ME').agg({
                            'close': 'last',
                            'volume': 'sum'
                        })
                        data[f"{ticker}_Close"] = alternative_monthly['close']
                        data[f"{ticker}_Volume"] = alternative_monthly['volume']
                        logger.success(f"Successfully processed {ticker} data using alternative columns")
                    except Exception as e2:
                        logger.exception(f"Error processing {ticker} with alternative columns: {str(e2)}")
                        continue
                except Exception as e:
                    logger.exception(f"Error processing {ticker} data: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.exception(f"Error in market data collection: {str(e)}")
            
        return data

    def collect_all_data(self):
        """
        Collect all necessary data for regime classification
        """
        logger.info("Starting data collection process")
        
        # Economic indicators from FRED (using Yahoo Finance symbols)
        fred_series = {
            'FEDFUNDS': 'FED_RATE',    # Federal Funds Rate
            'UNRATE': 'UNEMP',         # Unemployment Rate
            'M2SL': 'M2',              # M2 Money Supply (changed from M2 to M2SL)
            'BAMLH0A0HYM2': 'HY_SPREAD', # High Yield Spread
            'T10Y2Y': 'YIELD_SPREAD',  # 10Y-2Y Treasury Spread
            'DTWEXB': 'USD_INDEX',     # Dollar Index
            'GVZCLS': 'GOLD_VOL',         # Gold Volatility Index 
            'VIXCLS': 'VIX'               # VIX 
        }
        
        # Market data from Yahoo Finance
        market_tickers = [
            'SPY',    # S&P 500 ETF
            'TLT',    # 20+ Year Treasury Bond ETF
            'GLD',    # Gold ETF
            'DBC',    # Commodity ETF
            'EEM',    # Emerging Markets ETF
            'HYG',    # High Yield Bond ETF
            'LQD',    # Investment Grade Bond ETF
            'UUP'     # US Dollar Index ETF (changed from DXY)
        ]

        # Collect data from different sources
        logger.info("Fetching FRED data...")
        fred_data = self.get_fred_data(fred_series.keys())
        
        logger.info("Fetching market data...")
        market_data = self.get_market_data(market_tickers)
        
        logger.info("Fetching OECD data...")
        oecd_data = self.get_oecd_data()

        # Merge all data
        logger.debug("Merging data from all sources")
        all_data = pd.concat([fred_data, market_data, oecd_data], axis=1)
        
        # Ensure the index is monthly frequency and sorted
        all_data.index = pd.to_datetime(all_data.index)
        all_data = all_data.sort_index()
        
        # Report missing data statistics
        missing_stats = all_data.isna().sum()
        missing_pct = (missing_stats / len(all_data)) * 100
        
        logger.info("Missing data statistics:")
        for column in all_data.columns:
            missing_count = missing_stats[column]
            missing_percent = missing_pct[column]
            if missing_count > 0:
                logger.warning(f"{column}: {missing_count} missing values ({missing_percent:.1f}%)")
            else:
                logger.success(f"{column}: No missing values")
        
        # Create data directory if it doesn't exist
        os.makedirs('data', exist_ok=True)
        
        # Save to CSV
        output_path = 'data/market_data.csv'
        all_data.to_csv(output_path)
        logger.success(f"Data saved to {output_path}")
        
        # Also save a monthly summary
        monthly_path = 'data/market_data_monthly.csv'
        monthly_data = all_data.resample('ME').last()  # Note: This preserves NaN values
        monthly_data.to_csv(monthly_path)
        logger.success(f"Monthly data saved to {monthly_path}")
        
        logger.info(f"Data collection completed. Shape: {all_data.shape}")
        logger.info(f"Date range: {all_data.index.min()} to {all_data.index.max()}")
        return all_data

if __name__ == "__main__":
    try:
        collector = DataCollector()
        data = collector.collect_all_data()
    except Exception as e:
        logger.exception("Fatal error in data collection") 